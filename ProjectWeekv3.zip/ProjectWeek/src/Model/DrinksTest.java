package Model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class DrinksTest {

	@Test
	public void constructorTest() {
		Drinks drink = new Drinks();
		assertEquals(0, drink.getProductID());
		assertEquals(null, drink.getProductName());
		assertEquals(null, drink.getDesc());
		assertEquals(null, drink.getCategory());
		assertEquals(null, drink.getSupplier());
		assertEquals(0, drink.getPricePerGram());
		assertEquals(1, drink.getQuantity());
	}
	
	@Test
	public void getProductBySearchTest() {
		Drinks drink = new Drinks();
		ArrayList<Drinks> products = drink.getProductBySearch("Earl");
		assertEquals(3, products.size());
		assertEquals(products.get(0).getProductName(), "Earl Grey");
		assertEquals(products.get(0).getProductID(), 2);
		assertEquals(products.get(0).getDesc(), "grey");
		assertEquals(products.get(0).getCategory(), "herbal");
		assertEquals(products.get(0).getSupplier(), "pg tips");
		assertEquals(products.get(0).getPricePerGram(), 8);
		
		ArrayList<Drinks> product = drink.getProductBySearch("espress");
		assertEquals(1, product.size());
		assertEquals(product.get(0).getProductName(), "espresso");
		assertEquals(product.get(0).getProductID(), 1);
		assertEquals(product.get(0).getDesc(), "black");
		assertEquals(product.get(0).getCategory(), "caffinated");
		assertEquals(product.get(0).getSupplier(), "Azera");
		assertEquals(product.get(0).getPricePerGram(), 1.0); //make price per gram a double;
		
//		assertEquals(products.get(1).getProductName(), "Earl Blue");
//		assertEquals(products.get(1).getProductID(), 3);
//		assertEquals(products.get(1).getDesc(), "blue");
//		assertEquals(products.get(1).getCategory(), "herbal");
//		assertEquals(products.get(1).getSupplier(), "pg tips");
//		assertEquals(products.get(1).getPricePerGram(), 8);
//		
//		assertEquals(products.get(2).getProductName(), "Earl Yellow");
//		assertEquals(products.get(2).getProductID(), 4);
//		assertEquals(products.get(2).getDesc(), "yellow");
//		assertEquals(products.get(2).getCategory(), "herbal");
//		assertEquals(products.get(2).getSupplier(), "pg tips");
//		assertEquals(products.get(2).getPricePerGram(), 8);
//		
	}
	
	@Test
	public void addToBasketTest() {
		Drinks drink = new Drinks();
		drink.addToBasket(5, 1);
		
		ArrayList<Drinks> basket = drink.getBasket();
		assertEquals(basket.size(), 1);
		assertEquals(basket.get(0).getProductID(), 1);
		assertEquals(basket.get(0).getProductName(), "espresso");
		assertEquals(basket.get(0).getDesc(), "black");
		assertEquals(basket.get(0).getSupplier(), "Azera");
		assertEquals(basket.get(0).getCategory(), "caffinated");
		assertEquals(basket.get(0).getPricePerGram(), 1.0);
		assertEquals(basket.get(0).getQuantity(), 5);
		
		drink.addToBasket(3, 2);
		assertEquals(basket.size(), 2);
		assertEquals(basket.get(1).getProductID(), 2);
		assertEquals(basket.get(1).getProductName(), "Earl Grey");
		assertEquals(basket.get(1).getDesc(), "grey");
		assertEquals(basket.get(1).getSupplier(), "pg tips");
		assertEquals(basket.get(1).getCategory(), "herbal");
		assertEquals(basket.get(1).getPricePerGram(), 8.0);
		assertEquals(basket.get(1).getQuantity(), 3);
		
		//Testing if an unknown ID doesn't add to the basket size\\
		drink.addToBasket(3, 9);
		assertEquals(basket.size(), 2);
		
		drink.addToBasket(3, 0);
		assertEquals(basket.size(), 2);
		
		drink.addToBasket(3, -1);
		assertEquals(basket.size(), 2);
		
	}
	
	@Test
	public void calculatePrice() {
	
		//Calculating the amount in the basket. One quantity of the ID 2 is �8pGram. 
		//The grams requested is 5. Therefore one item is (8*5)*1 = 40. 3 items of ID 2 is 40*3, therefore we expect �120. 
		Drinks drink = new Drinks();
		drink.addToBasket(3, 2);

		ArrayList<Drinks> basket = drink.getBasket();
		
		assertEquals(basket.size(), 1);
		assertEquals(basket.get(0).getQuantity(), 3);
		
		double price = drink.calculateBasket(5);
		
		assertEquals(price, 120.0);	
		
		
		//Calculating the amount in the basket. One quantity of ID 1 is �1pGram.
		//The grams requested is 5. Therefore one item is (1*1)*5 = �5. 5 items of ID 1 is 5*5, therefore we expect �25. 
		Drinks drink1 = new Drinks();
		drink1.addToBasket(5, 1);

		ArrayList<Drinks> basket1 = drink1.getBasket();
		
		assertEquals(basket1.size(), 1);
		assertEquals(basket1.get(0).getQuantity(), 5);
		
		double price1 = drink1.calculateBasket(5);
		
		assertEquals(price1, 25);
		
		
		//Checking if two addToBasket methods provide the expected result.
		//Calculations shown below. 
		Drinks drink2 = new Drinks();
		drink2.addToBasket(5, 1); //1*10 = 10*5 = 50
		drink2.addToBasket(2, 2); //8*10 = 80*2 = 160. Expecting 210. 
		
		ArrayList<Drinks> basket2 = drink2.getBasket();
		
		assertEquals(basket2.size(), 2);
		assertEquals(basket2.get(0).getQuantity(), 5);
		assertEquals(basket2.get(1).getQuantity(), 2);
		
		double price2 = drink2.calculateBasket(10);
		
		assertEquals(price2, 210);
		
		
		//Checking if an addToBasket is given an invalid ID, that the price won't be affected and the expected price 
		//An invalid ID means nothing can be found through an SQL query as its impossible by our design (ID starts at 1 incremented)
		//the result (25).
		Drinks drink3 = new Drinks();
		drink3.addToBasket(5, 1); //1*5 = 5*5 = 25
		drink3.addToBasket(2, 0); //8*10 = 80*2 = 160. Expecting 210. 
		
		ArrayList<Drinks> basket3 = drink3.getBasket();
		
		assertEquals(basket3.size(), 1);
		assertEquals(basket3.get(0).getQuantity(), 5);
		
		double price3 = drink3.calculateBasket(5);
		
		assertEquals(price3, 25);
		
		//Checking if the method doesn't add the item to the basket if the quantity provided 
		//is less than, or equal to, 0. If the quantity is 0, then it sets the productID to 0, which therefore
		//nullifies the sql query and stops the item being added to the basket. 
		Drinks drink4 = new Drinks();
		drink4.addToBasket(5, 1); //1*5 = 5*5 = 25
		drink4.addToBasket(0, 1); //8*10 = 80*2 = 160. Expecting 210. 
		
		ArrayList<Drinks> basket4 = drink4.getBasket();
		
		assertEquals(basket4.size(), 1);
		assertEquals(basket4.get(0).getQuantity(), 5);
		
		double price4 = drink4.calculateBasket(5);
		
		assertEquals(price4, 25);
		
		//Testing if both values are 0.
		Drinks drink5 = new Drinks();
		drink5.addToBasket(0, 0);
		drink5.addToBasket(3, 1); //1*5 = 5*3 = 15
		drink5.addToBasket(0, 1); //8*10 = 80*2 = 160. Expecting 210. 
		
		ArrayList<Drinks> basket5 = drink5.getBasket();
		
		assertEquals(basket5.size(), 1);
		assertEquals(basket5.get(0).getQuantity(), 3);
		
		double price5 = drink5.calculateBasket(5);
		
		assertEquals(price5, 15);
		
	}
	
	
}
