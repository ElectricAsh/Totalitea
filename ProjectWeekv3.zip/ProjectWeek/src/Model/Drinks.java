package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import Util.DBConnector;


public class Drinks {

	private int productID;
	private String desc;
	private String productName;
	private String category;
	private String supplier;
	private double pricePerGram;
	private int quantity; 
	private ArrayList<Drinks> basket = new ArrayList<>();

	/**
	 * This class controls the circumstances in which a new Booking instance can be
	 * created. This enables it to track the new/existing status of a record.
	 */
	public Drinks() {
		productID = 0;
		desc = null;
		productName = null;
		category = null;
		supplier = null;
		pricePerGram = 0;
		quantity = 1;
	}

	public ArrayList<Drinks> getProductBySearch(String searchQuery) {
		/**
		 * Below: try-with-resources - resources will be closed correctly at the end of the try block's execution.
		 */
		ArrayList<Drinks> productsFound = new ArrayList<>();
		try (
			Connection con = DBConnector.getConnection();	
			PreparedStatement ps = con.prepareStatement( "SELECT * FROM Products WHERE ProductName LIKE ? "
																+ "OR Description LIKE ? OR Category LIKE ?");)
		 {
			ps.setString(1, searchQuery+"%");
			ps.setString(2, searchQuery+"%");
			ps.setString(3, searchQuery+"%");
			try (
					ResultSet resultSet = ps.executeQuery();
					
			) {
				// Can be hard to determine number of results without reading full ResultSet
				while(resultSet.next()) {
					Drinks d = new Drinks();
					d.setProductID(resultSet.getInt("ProductID"));
					d.setProductName(resultSet.getString("ProductName"));
					d.setDesc(resultSet.getString("Description"));
					d.setCategory(resultSet.getString("Category"));
					d.setSupplier(resultSet.getString("Supplier"));
					d.setPricePerGram(resultSet.getInt("PricePerGram"));
					//System.out.println(desc);
					productsFound.add(d);
				}
				return productsFound;
			}
		} catch(SQLException e) {
			System.err.println(e);
			e.printStackTrace();
		}
		return null;
		
	}
	
	public void addToBasket(int quantity, int productID) {
			if(quantity <= 0) {
				productID = 0;
			}
		try (
			Connection con = DBConnector.getConnection();	
			PreparedStatement ps = con.prepareStatement( "SELECT * FROM Products WHERE productID = ?");)
		 {
			ps.setInt(1, productID);
			
			try (
					ResultSet resultSet = ps.executeQuery();
					
			) {
		
				if(resultSet.next()) {
					Drinks d = new Drinks();
					d.setProductID(resultSet.getInt("ProductID"));
					d.setProductName(resultSet.getString("ProductName"));
					d.setDesc(resultSet.getString("Description"));
					d.setCategory(resultSet.getString("Category"));
					d.setSupplier(resultSet.getString("Supplier"));
					d.setPricePerGram(resultSet.getInt("PricePerGram"));
					d.setQuantity(quantity);
					//System.out.println(desc);
					basket.add(d);
				}
			}
		} catch(SQLException e) {
			System.err.println(e);
			e.printStackTrace();
		}
	}
	
	public double calculateBasket(int chosenWeight) {
		double price = 0; 
	ArrayList<Drinks> basket = getBasket();
	for(Drinks product: basket) {
		int quantity = product.getQuantity();
		double pricePerGram = product.getPricePerGram();
		price = price + (pricePerGram*chosenWeight) * quantity;
	}
	return price;
	
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public double getPricePerGram() {
		return pricePerGram;
	}

	public void setPricePerGram(int pricePerGram) {
		this.pricePerGram = pricePerGram;
	}
	
	public ArrayList<Drinks> getBasket() {
		return basket;
	}

	public void setBasket(ArrayList<Drinks> basket) {
		this.basket = basket;
	}

}