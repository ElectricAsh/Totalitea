package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import Util.DBConnector;


public class Product {

	private int productID;
	private static String desc;
	private String productName;
	private String category;
	private String supplier;
	private int pricePerGram;
	private int quantity; 
	private ArrayList<Product> basket = new ArrayList<>();

	/**
	 * This class controls the circumstances in which a new Booking instance can be
	 * created. This enables it to track the new/existing status of a record.
	 */
	public Product() {
		productID = 0;
		desc = null;
		productName = null;
		category = null;
		supplier = null;
		pricePerGram = 0;
		quantity = 1;
	}

	public ArrayList<Product> getProductBySearch(String searchQuery) {
		/**
		 * Below: try-with-resources - resources will be closed correctly at the end of the try block's execution.
		 */
		ArrayList<Product> productsFound = new ArrayList<>();
		try (
			Connection con = DBConnector.getConnection();	
			PreparedStatement ps = con.prepareStatement( "SELECT * FROM Products WHERE ProductName LIKE ? "
																+ "OR Description LIKE ? OR Category LIKE ?");)
		 {
			ps.setString(1, searchQuery+"%");
			ps.setString(2, searchQuery+"%");
			ps.setString(3, searchQuery+"%");
			try (
					ResultSet resultSet = ps.executeQuery();
					
			) {
				// Can be hard to determine number of results without reading full ResultSet
				if(resultSet.next()) {
					Product p = new Product();
					p.setProductID(resultSet.getInt("ProductID"));
					p.setProductName(resultSet.getString("ProductName"));
					p.setDesc(resultSet.getString("Description"));
					p.setCategory(resultSet.getString("Category"));
					p.setSupplier(resultSet.getString("Supplier"));
					p.setPricePerGram(resultSet.getInt("PricePerGram"));
					//System.out.println(desc);
					productsFound.add(p);
				}
				return productsFound;
			}
		} catch(SQLException e) {
			System.err.println(e);
			e.printStackTrace();
		}
		return null;
		
	}
	
	public void addToBasket(int quantity, int productID) {
		
		try (
			Connection con = DBConnector.getConnection();	
			PreparedStatement ps = con.prepareStatement( "SELECT * FROM Products WHERE productID = ?");)
		 {
			ps.setInt(1, productID);
			
			try (
					ResultSet resultSet = ps.executeQuery();
					
			) {
		
				if(resultSet.next()) {
					Product p = new Product();
					p.setProductID(resultSet.getInt("ProductID"));
					p.setProductName(resultSet.getString("ProductName"));
					p.setDesc(resultSet.getString("Description"));
					p.setCategory(resultSet.getString("Category"));
					p.setSupplier(resultSet.getString("Supplier"));
					p.setPricePerGram(resultSet.getInt("PricePerGram"));
					p.setQuantity(quantity);
					//System.out.println(desc);
					basket.add(p);
				}
			}
		} catch(SQLException e) {
			System.err.println(e);
			e.printStackTrace();
		}
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public int getPricePerGram() {
		return pricePerGram;
	}

	public void setPricePerGram(int pricePerGram) {
		this.pricePerGram = pricePerGram;
	}
	
	public ArrayList<Product> getBasket() {
		return basket;
	}

	public void setBasket(ArrayList<Product> basket) {
		this.basket = basket;
	}

}