package Model;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Util.DBConnector;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Product p = new Product();
		DBConnector db = new DBConnector();
		db.loadDriver();
		db.connect();
		
		String searchInfo = request.getParameter("Searchbar");

//		if(db.searchCheck(searchInfo)){
//			System.out.println("SEARCH METHOD WORKS");
//			response.sendRedirect("Loggedin.jsp");
//		}
//		else {
//			System.out.println("SEARCH METHOD, SEARCH UNSUCCESSFUL");
//			response.sendRedirect("error.jsp");
//			
//		}
		
		ArrayList<Product> product2 = p.getProductBySearch(searchInfo);
		
		for(Product product:product2) {
		System.out.println(product.getProductID());
		System.out.println(product.getProductName());
		System.out.println(product.getDesc());
		System.out.println(product.getCategory());
		System.out.println(product.getSupplier());
		System.out.println(product.getPricePerGram());
		}
		
	}

}
