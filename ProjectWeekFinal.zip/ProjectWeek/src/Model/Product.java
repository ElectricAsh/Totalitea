package Model;

public class Product{
	protected int productID;
	protected String desc;
	protected String productName;
	protected String category;
	protected String supplier;
	protected double pricePerGram;
	protected int quantity; 
	protected int weight;
	protected double price;
	protected String type;
	
	public Product() {
		productID = 0;
		desc = null;
		productName = null;
		category = null;
		supplier = null;
		quantity = 1;
		weight = 0;
		price = 0.0;
		type = "";
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public double getPricePerGram() {
		return pricePerGram;
	}

	public void setPricePerGram(double pricePerGram) {
		this.pricePerGram = pricePerGram;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
}