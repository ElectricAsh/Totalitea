package Model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Util.DBConnector;

/**
 * Servlet implementation class BasketServlet
 */
@WebServlet("/BasketServlet")
public class BasketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BasketServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ShopInteraction p = new ShopInteraction();
		int qty = 0;
		int id = 0;
		//String searchInfo = request.getParameter("Searchbar");
		try {
		qty = Integer.parseInt(request.getParameter("qty"));
		id  = Integer.parseInt(request.getParameter("productid"));
		}catch(NumberFormatException e){
			System.out.println("Invalid input");
		}
		
		ArrayList<Product> basket = (ArrayList<Product>) request.getSession().getAttribute("basket");
		//response.sendRedirect("SearchResults.jsp");
		if(basket == null) {
			basket = new ArrayList<Product>();
		}
		if(qty > 0) {
		basket.add(p.addToBasket(qty, id)); //First param is the quantity, the second param is the ID in the SQL table.
		
		}
		else
			{
			System.out.println("Error, input cannot be less than 0.");
			}
		
		
		request.getSession().setAttribute("basket", basket);
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/SearchServlet");
		dispatcher.forward(request, response);
		
		for(Product product:basket) {
		System.out.println(product.getProductID());
		System.out.println(product.getProductName());
		System.out.println(product.getDesc());
		System.out.println(product.getCategory());
		System.out.println(product.getSupplier());
		System.out.println(product.getQuantity());
		}
		//response.sendRedirect("SearchServlet");*/
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
