package Model;

public class Middleware {
	private int x;
	
	public Middleware() {
		x= 12345;
	}
	
	public int getX() {
		return x;
	}
}
