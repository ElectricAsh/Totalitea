package Model;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductPage
 */
@WebServlet("/ProductPageServlet")
public class ProductPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductPageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		ShopInteraction p = new ShopInteraction();
		int id = 0;
		id  = Integer.parseInt(request.getParameter("productid"));
		
		Product product = p.getProduct(id);	
		if(product instanceof Drinks) {
			Drinks dProduct = (Drinks)product;
			request.getSession().setAttribute("dProduct", dProduct);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/DrinkProductPage.jsp");
			dispatcher.forward(request, response);
		}
		if(product instanceof Cake) {
			Cake cProduct = (Cake)product;
			request.getSession().setAttribute("cProduct", cProduct);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/CakeProductPage.jsp");
			dispatcher.forward(request, response);
		}
			
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
