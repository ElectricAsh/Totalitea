package Model;

public class Cake extends Product {
	
	private int hasNuts;
	private int hasDairy;
	private int sugarAmt;
	private int saturatedFat;
	
	

	public Cake() {
		super();
	}
	
	public int getHasNuts() {
		return hasNuts;
	}

	public void setHasNuts(int hasNuts) {
		this.hasNuts = hasNuts;
	}

	public int getHasDairy() {
		return hasDairy;
	}

	public void setHasDairy(int hasDairy) {
		this.hasDairy = hasDairy;
	}

	public int getSugarAmt() {
		return sugarAmt;
	}

	public void setSugarAmt(int sugarAmt) {
		this.sugarAmt = sugarAmt;
	}

	public int getSaturatedFat() {
		return saturatedFat;
	}

	public void setSaturatedFat(int saturatedFat) {
		this.saturatedFat = saturatedFat;
	}
}
