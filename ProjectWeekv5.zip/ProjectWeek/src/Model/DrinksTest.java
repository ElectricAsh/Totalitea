package Model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DrinksTest {

	@Test
	public void constructorTest() {
		Drinks drink = new Drinks();
		assertEquals(0, drink.getProductID());
		assertEquals(null, drink.getProductName());
		assertEquals(null, drink.getDesc());
		assertEquals(null, drink.getCategory());
		assertEquals(null, drink.getSupplier());
		assertEquals(0, drink.getPricePerGram());
		assertEquals(1, drink.getQuantity());
	}	
}
